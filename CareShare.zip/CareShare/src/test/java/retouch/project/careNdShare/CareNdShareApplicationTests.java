package retouch.project.careNdShare;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CareNdShareApplicationTests {

	@Test
	void contextLoads() {
	}

}

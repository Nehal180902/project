package retouch.project.careNdShare.entity;

// PurchaseStatus.java

public enum PurchaseStatus {
    PENDING,
    CONFIRMED,
    SHIPPED,
    DELIVERED,
    CANCELLED
}